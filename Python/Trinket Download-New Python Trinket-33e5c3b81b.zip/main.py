while(1):        
        a=input()
        n=int(input())
        for i in a:
                if((ord(i)+n)>122):
                        print(chr((ord(i)+n)-122+96),end='')
                        
                elif(ord(i)==32):
                        print(chr(ord(i)),end='')
                else:
                      print(chr(ord(i)+n),end='')
        print()
        
        


        
        
        
